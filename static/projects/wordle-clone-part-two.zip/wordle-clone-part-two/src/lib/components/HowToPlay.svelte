<script>

  import { showHowToPlay } from "../store";

</script>

<h1>HowToPlay component <button on:click={() => $showHowToPlay = false}>X</button></h1>
