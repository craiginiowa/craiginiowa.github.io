<script>
  import Welcome from "./lib/components/Welcome.svelte";
  import Wordle from "./lib/components/Wordle.svelte";
  import { showWelcome } from "./lib/store";

</script>

<div class="wordle-clone">
  {#if $showWelcome}
  <Welcome />
  {:else}
  <Wordle />
  {/if}
</div>

<style>
  .wordle-clone {    
    background-color: white;
    height: 100vh;
    position: relative;
    width: 100vw;
  }
</style>