# Wordle Clone

This is Part Two of building a Wordle clone as detailed here: [https://craiginiowa.com/blog/wordle-clone](https://craiginiowa.com/blog/wordle-clone-part-two).

## Installing the project

The project required `node` (version 18+).

Unzip the file, open a Terminal window, and `cd` into the `wordle-clone` directory.

* Run `npm install`.
* Run `npm run dev`. You should get a response that the server is running at `http://localhost:3000`. 
* Type "o" to open that address in your default browser or manually enter it into the location bar.
