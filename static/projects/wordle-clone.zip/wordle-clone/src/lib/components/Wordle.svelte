<script>
  import Header from "./Header.svelte";
  import HowToPlay from "./HowToPlay.svelte";
  import Statistics from "./Statistics.svelte";
  import Settings from "./Settings.svelte";
  import {
    showHowToPlay,
    showStatistics,
    showSettings,

    showWelcome

  } from "../store";

  function reset() {
    $showWelcome = true;
    $showHowToPlay = false;
    $showStatistics = false;
    $showSettings = false;
  }
</script>

<Header />

{#if $showHowToPlay}
<HowToPlay />
{:else if $showStatistics}
<Statistics />
{:else if $showSettings}
<Settings />
{/if}

<div class="back-to-welcome">
  <button on:click={reset}>&larr; Back to welcome screen</button>
</div>

<style>
  h1 {
    margin: 0;
  }

  .back-to-welcome {
    left: 50%;
    position: fixed;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .back-to-welcome button {
    background: none;
    border: none;
    color: blue;
    cursor: pointer;
    font-size: 1.5rem;
  }
</style>