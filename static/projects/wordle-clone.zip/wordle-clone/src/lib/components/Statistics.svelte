<script>

  import { showStatistics } from "../store";

</script>

<h1>Statistics component <button on:click={() => $showStatistics = false}>X</button></h1>