<script>
  import { showSettings } from "../store";

</script>
<h1>Settings component <button on:click={() => $showSettings = false}>X</button></h1>